import 'dart:convert';
import 'package:http/http.dart';

class dashboardData {
  final String users;
  final String admin;
  final String section;
  final String total;
  final String editedreords;
  final String available;

  String url = 'http://10.0.2.2:8000/api/get_stat';

  dashboardData({
   this.users,
   this.admin,
   this.section,
   this.total,
   this.editedreords,
   this.available
});

  factory dashboardData.fromJson(Map<String, dynamic> json) {
    return dashboardData(
      student: json['total_users'].toString(),
      teacher: json['total_admin'].toString(),
      section: json['total_section'].toString(),
      totalSeat: json['total_together'].toString(),
      bookedSeat: json['edited_records'].toString(),
      availableSeat: json['available'].toString()

    );
  }

  Future<dashboardData> dashboardApi() async {
    Response response = await get(url);

    if(response.statusCode == 200) {
      return dashboardData.fromJson(jsonDecode(response.body));

    } else {
      return null;

    }
  }

}